library(testthat)
library(glyphs)

test_check("glyphs")
